At this stage, we don't have a project structured yet.
Follow the next section.