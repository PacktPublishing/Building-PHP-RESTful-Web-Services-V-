At this stage, we are installing Wamp Server.
Following it, we are configuring our development environment
with installing Composer.
We are installing Silex using Composer.