We go on providing security with uploading our files into Amazon's s3
cloud storage.