At this stage, we can provide security over file uploading
with new middleware components.