<?php

namespace Tweetify\Models;

class Message extends \Illuminate\Database\Eloquent\Model
{
	
}