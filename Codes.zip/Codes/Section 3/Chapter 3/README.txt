Here, we create the database, create tables inside the database.
More, we create the first middleware for the API.