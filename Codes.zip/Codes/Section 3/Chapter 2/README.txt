Here we are creating our first route.
At first we start simple, later we will work iteratively.