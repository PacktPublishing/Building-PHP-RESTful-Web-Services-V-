We turn our read-only API into a read-write API.
Now we can create messages.